//
//  ViewController.h
//  视频通讯demo
//
//  Created by ozx on 15/7/15.
//  Copyright (c) 2015年 ozx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

