//
//  chatWithUserController.m
//  视频通讯demo
//
//  Created by ozx on 15/7/16.
//  Copyright (c) 2015年 ozx. All rights reserved.
//

#import "chatWithUserController.h"
#import "EaseMob.h"
#import <AVFoundation/AVFoundation.h>
#import "CallViewController.h"
#define Swidth [UIScreen mainScreen].bounds.size.width

@interface chatWithUserController ()<UIGestureRecognizerDelegate,IChatManagerDelegate, EMCallManagerDelegate>
{
    UITextField * sendContext;
    EMConversation *conversation ;
    UITextView * textview;
}

@end

@implementation chatWithUserController
@synthesize userName  = userName;

-(void)viewDidLoad{
    [super viewDidLoad];
    
    [[EaseMob sharedInstance].chatManager removeDelegate:self];
//    //注册为SDK的ChatManager的delegate
    [[EaseMob sharedInstance].chatManager addDelegate:self delegateQueue:nil];
    
    [[EaseMob sharedInstance].callManager removeDelegate:self];
    [[EaseMob sharedInstance].callManager addDelegate:self delegateQueue:nil];
    
    [self setupTheBtn];
    
    //开始新建会话/获取会话列表
    conversation = [[EaseMob sharedInstance].chatManager conversationForChatter:userName conversationType:eConversationTypeChat];
    
//    [conversation markAllMessagesAsRead:YES];
    
     textview= [[UITextView alloc] initWithFrame:CGRectMake(0, 64, Swidth, 200)];
    [self.view addSubview:textview];
    textview.backgroundColor = [UIColor grayColor];
    
    UIPanGestureRecognizer *panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanFrom:)];
    [self.view addGestureRecognizer:panRecognizer];
    panRecognizer.delegate = self;
    
    //先请求了照相隐私
    NSString *mediaType = AVMediaTypeVideo;
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
    if (authStatus==AVAuthorizationStatusNotDetermined) {
        [AVCaptureDevice requestAccessForMediaType:mediaType completionHandler:^(BOOL granted) {//请求访问照相功能.
            if(granted){//点击允许访问时调用
                //用户明确许可与否，媒体需要捕获，但用户尚未授予或拒绝许可。
                NSLog(@"Granted access to %@", mediaType);
                
            }
            else {
                NSLog(@"Not granted access to %@", mediaType);
            }
        }];
        
    }
    
    //给对话框赋值,填充之前的聊天记录.
    [self addtext];
    
}

-(void)dealloc{
    [[EaseMob sharedInstance].chatManager removeDelegate:self];
    [[EaseMob sharedInstance].callManager removeDelegate:self];
}

-(void)setupTheBtn{
    UIButton *b = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
    [b setTitle:@"back" forState:UIControlStateNormal];
    [b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    b.backgroundColor = [UIColor clearColor];
    [b addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchDown];
    UIBarButtonItem * left = [[UIBarButtonItem alloc] initWithCustomView:b];
    //    self.navigationController.navigationItem.leftBarButtonItem = left;
    
    UIButton *b1 = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
    [b1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [b1 setTitle:@"done" forState:UIControlStateNormal];
    b1.backgroundColor = [UIColor clearColor];
    [b1 addTarget:self action:@selector(hehe) forControlEvents:UIControlEventTouchDown];
    UIBarButtonItem * right = [[UIBarButtonItem alloc] initWithCustomView:b1];
    
    UINavigationBar * bar = [[UINavigationBar alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 64)];
    UINavigationItem * title = [[UINavigationItem alloc] initWithTitle:userName];
    NSLog(@"%@",userName);
    [bar pushNavigationItem:title animated:NO];
    title.leftBarButtonItem = left;
    title.rightBarButtonItem = right;
    [self.view addSubview:bar];
    self.view.backgroundColor = [UIColor yellowColor];
    
    sendContext = [[UITextField alloc] initWithFrame:CGRectMake(0, 280, Swidth, 40)];
    [self.view addSubview:sendContext];
    [sendContext setBorderStyle:UITextBorderStyleRoundedRect];
    
    
    UIButton * send = [[UIButton alloc] initWithFrame:CGRectMake(0, 320, Swidth, 40)];
    [self.view addSubview:send];
    send.backgroundColor  = [UIColor redColor];
    [send setTitle:@"send" forState:UIControlStateNormal];
    [send setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [send addTarget:self action:@selector(send:) forControlEvents:UIControlEventTouchDown];
    
    //视频聊天按钮
    UIButton * btn_video = [[UIButton alloc] initWithFrame:CGRectMake(0, 400, Swidth , 40)];
    btn_video.backgroundColor  = [UIColor redColor];
    [btn_video setTitle:@"视频聊天" forState:UIControlStateNormal];
    [btn_video setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.view addSubview:btn_video];
    [btn_video addTarget:self action:@selector(openTheVideo:) forControlEvents:UIControlEventTouchDown];
    
}

-(void)openTheVideo:(UIButton *)btn{
    BOOL isopen = [self canVideo];
    EMError *error = nil;
    EMCallSession *callSession = nil;
    if (!isopen) {
        NSLog(@"不能打开视频");
        return ;
    }
    //这里发送视频请求
    callSession = [[EaseMob sharedInstance].callManager asyncMakeVideoCall:userName timeout:50 error:&error];
    //请求完以后,开始做下面的
    if (callSession && !error) {
        [[EaseMob sharedInstance].callManager removeDelegate:self];
        
        CallViewController *callController = [[CallViewController alloc] initWithSession:callSession isIncoming:NO];
        callController.modalPresentationStyle = UIModalPresentationOverFullScreen;
        [self presentViewController:callController animated:NO completion:nil];
    }
    
    if (error) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"error", @"error") message:error.description delegate:nil cancelButtonTitle:NSLocalizedString(@"ok", @"OK") otherButtonTitles:nil, nil];
        [alertView show];
    }
    
}

-(BOOL)canVideo{
    BOOL canvideo = YES;
    NSString *mediaType = AVMediaTypeVideo;// Or AVMediaTypeAudio
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
    NSLog(@"---cui--authStatus--------%d",authStatus);
    // This status is normally not visible—the AVCaptureDevice class methods for discovering devices do not return devices the user is restricted from accessing.
    if(authStatus ==AVAuthorizationStatusRestricted){//此应用程序没有被授权访问的照片数据。可能是家长控制权限。
        NSLog(@"Restricted");
        canvideo = NO;
        return canvideo;
    }else if(authStatus == AVAuthorizationStatusDenied){//用户已经明确否认了这一照片数据的应用程序访问.
        // The user has explicitly denied permission for media capture.
        NSLog(@"Denied");     //应该是这个，如果不允许的话
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示"
                                                        message:@"请在设备的\"设置-隐私-相机\"中允许访问相机。"
                                                       delegate:self
                                              cancelButtonTitle:@"确定"
                                              otherButtonTitles:nil];
        [alert show];
        alert = nil;
        canvideo = NO;
        return canvideo;
    }
    else if(authStatus == AVAuthorizationStatusAuthorized){//允许访问,用户已授权应用访问照片数据.
        // The user has explicitly granted permission for media capture, or explicit user permission is not necessary for the media type in question.
        NSLog(@"Authorized");
        canvideo = YES;
        return canvideo;
    }else if(authStatus == AVAuthorizationStatusNotDetermined){//用户尚未做出了选择这个应用程序的问候
        // Explicit user permission is required for media capture, but the user has not yet granted or denied such permission.
        [AVCaptureDevice requestAccessForMediaType:mediaType completionHandler:^(BOOL granted) {//请求访问照相功能.
            //应该在打开视频前就访问照相功能,不然下面返回不了值啊.
            if(granted){//点击允许访问时调用
                //用户明确许可与否，媒体需要捕获，但用户尚未授予或拒绝许可。
                NSLog(@"Granted access to %@", mediaType);
                
            }
            else {
                NSLog(@"Not granted access to %@", mediaType);
            }
        }];
    }else {
        NSLog(@"Unknown authorization status");
        canvideo = NO;
    }
    return canvideo;
}

-(void) addtext{
    //从会话管理者中获得当前会话.
    EMConversation *conversation2 =  [[EaseMob sharedInstance].chatManager conversationForChatter:userName conversationType:0] ;
    
    //conversation
    NSString * context = @"";//用于制作对话框中的内容.(现在还没有分自己发送的还是别人发送的.)
    NSArray * arrcon;
    NSArray * arr;
    long long timestamp = [[NSDate date] timeIntervalSince1970] * 1000 + 1;//制作时间戳
    arr = [conversation2 loadAllMessages]; // 获得内存中所有的会话.
    arrcon = [conversation2 loadNumbersOfMessages:10 before:timestamp]; //根据时间获得5调会话. (时间戳作用:获得timestamp这个时间以前的所有/5会话)
    
    for (EMMessage * hehe in arrcon) {
        id<IEMMessageBody> messageBody = [hehe.messageBodies firstObject];
        NSString *messageStr = nil;
        messageStr = ((EMTextMessageBody *)messageBody).text;
//        [context stringByAppendingFormat:@"%@",messageStr ];
        
        if (![hehe.from isEqualToString:userName]) {//如果是自己发送的.
            context = [NSString stringWithFormat:@"%@\n\t\t\t\t\t我说:%@",context,messageStr];
        }else{
            context = [NSString stringWithFormat:@"%@\n%@",context,messageStr];
        }
        
    }
    
    textview.text = context;
}


-(void)hehe{
    [self.view endEditing:YES];
    
}

-(void)handlePanFrom:(id)sender{
    [self.view endEditing:YES];
}

-(void)back:(UIButton *)sender{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}


#pragma mark - IChatManagerDelegate
#pragma mark - 发送信息
-(void) send:(UIButton *)sender{
//         conversation= [[EaseMob sharedInstance].chatManager conversationForChatter:@"ozxozx" conversationType:eConversationTypeChat];
    
    
    EMChatText *txtChat = [[EMChatText alloc] initWithText:sendContext.text];
    EMTextMessageBody *body = [[EMTextMessageBody alloc] initWithChatObject:txtChat];

    // 生成message
    EMMessage *message = [[EMMessage alloc] initWithReceiver:userName bodies:@[body]];
    message.messageType = eMessageTypeChat;
    

    EMError *error = nil;
    
    id <IChatManager> chatManager = [[EaseMob sharedInstance] chatManager];
//    [chatManager asyncResendMessage:message progress:nil];
    [chatManager sendMessage:message progress:nil error:&error];
    if (error) {
        UIAlertView * a = [[UIAlertView alloc] initWithTitle:@"error" message:@"发送失败" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        [a show];
    }else {
        textview.text = [NSString stringWithFormat:@"%@\n\t\t\t\t\t我说:%@",textview.text,sendContext.text];
    }
}

/*!
 @method
 @brief 收到消息时的回调
 @param message      消息对象
 @discussion 当EMConversation对象的enableReceiveMessage属性为YES时, 会触发此回调
 针对有附件的消息, 此时附件还未被下载.
 附件下载过程中的进度回调请参考didFetchingMessageAttachments:progress:,
 下载完所有附件后, 回调didMessageAttachmentsStatusChanged:error:会被触发
 */
-(void)didReceiveMessage:(EMMessage *)message
{
    NSLog(@"%s",__func__);
    //因为不是uitableview,所以直接在textview上输出就好,不用下面的代码,搞datasource;
    id<IEMMessageBody> messageBody = [message.messageBodies firstObject];
    NSString *messageStr = nil;
    messageStr = ((EMTextMessageBody *)messageBody).text;
    textview.text = [NSString stringWithFormat:@"%@\n%@",textview.text,messageStr];
    
//    if ([conversation.chatter isEqualToString:message.conversationChatter]) {
//        [self addMessage:message];
//        if ([self shouldAckMessage:message read:NO])
//        {
//            [self sendHasReadResponseForMessages:@[message]];
//        }
//        if ([self shouldMarkMessageAsRead])
//        {
//            [self markMessagesAsRead:@[message]];
//        }
//    }
}
/*!
 @method
 @brief 收到消息时的回调
 @param cmdMessage      消息对象
 @discussion 当EMConversation对象的enableReceiveMessage属性为YES时, 会触发此回调
 针对有附件的消息, 此时附件还未被下载.
 附件下载过程中的进度回调请参考didFetchingMessageAttachments:progress:,
 下载完所有附件后, 回调didMessageAttachmentsStatusChanged:error:会被触发
 */
-(void)didReceiveCmdMessage:(EMMessage *)message
{
        NSLog(@"%s",__func__);//然并卵
//    if ([_conversation.chatter isEqualToString:message.conversationChatter]) {
//        [self showHint:NSLocalizedString(@"receiveCmd", @"receive cmd message")];
//    }
}


-(void)didUnreadMessagesCountChanged
{
    NSLog(@"%s",__func__);
}

@end
